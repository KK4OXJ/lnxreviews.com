        <footer>
            <div class="footer-nav">
			    <a href="donate.html" class="footer-link" id="donate">Donate</a>
			    <a href="contact.html" class="footer-link" id="contact">Contact</a>
			    <a href="team.html" class="footer-link" id="team">Team</a>
            </div>
		
		    <p class="copyright-notice">&copy; Copyrighted and designed by Zeke Y 2014 | <a href="wp-admin">Admin</a></p>
        </footer>
    </body>
</html>