<?php get_header() ?>

<h1>Sorry, we couldn't find that page</h1>

<?php get_footer() ?>